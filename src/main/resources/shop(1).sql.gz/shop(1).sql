-- Adminer 4.8.1 MySQL 8.0.32 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `cart`;
CREATE TABLE `cart` (
  `cart_id` int NOT NULL AUTO_INCREMENT,
  `good_id` int NOT NULL,
  `count` int NOT NULL DEFAULT '1',
  PRIMARY KEY (`cart_id`),
  KEY `good_id` (`good_id`),
  CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`good_id`) REFERENCES `goods` (`good_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `cart` (`cart_id`, `good_id`, `count`) VALUES
(7,	1,	1);

DROP TABLE IF EXISTS `goods`;
CREATE TABLE `goods` (
  `good_id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `price` int NOT NULL,
  `info` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `date_create` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`good_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `goods` (`good_id`, `title`, `price`, `info`, `date_create`) VALUES
(1,	'Audi',	1250,	'В наличии',	'2023-03-13 15:49:53'),
(2,	'BMW',	1500,	'Под заказ',	'2023-03-13 15:49:53'),
(3,	'Skoda',	900,	'В наличии',	'2023-03-13 15:50:43'),
(4,	'VW',	950,	'Под заказ',	'2023-03-13 15:50:43');

-- 2023-03-19 18:46:24
